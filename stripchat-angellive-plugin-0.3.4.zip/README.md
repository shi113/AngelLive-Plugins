# Stripchat Angel Live Plugin 0.3.4

- 列表 / 搜索 / 详情 / 状态 / 播放
- `liveCodeType` 保持宿主要求的 `m3u8`，不更改 LiveQualityModel 输出结构
- 播放优先走解析代理 `liveparse.carsonn.works/stripchatparse`；代理无可用清晰度时回退直连 HLS
- 代理清晰度去重并按分辨率降序，自动档始终选当前返回列表中的最高分辨率
- 直连 HLS master 的相对子清单路径会解析为完整 URL
- 直连回退先并发探测多个 CDN 的 auto 清单，再并发探测标准 master，减少串行超时
- 说明：插件负责取流与线路选择；实际缓冲、预读和解码仍由 AngelLive 宿主播放器内核决定
