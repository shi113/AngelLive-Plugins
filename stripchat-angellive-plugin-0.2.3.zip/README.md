# Stripchat Angel Live Plugin 0.2.3

- 分类 / 房间列表 / 搜索 / 详情 / 直播状态
- 播放暂不提供（宿主显示「获取播放地址：不可用」属预期）
- 收藏由 Angel Live 本地管理

## 数据接口
- 列表：`/api/front/models`（优先）或 `/api/front/v2/models`
- 搜索：`/api/front/v4/models/search/suggestion`
- 详情：`/api/front/v2/models/{id}/cam`
