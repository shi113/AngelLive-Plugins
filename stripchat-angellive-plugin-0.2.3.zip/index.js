(function () {
  "use strict";

  var API = "https://stripchat.com/api/front";
  var REFERER = "https://stripchat.com/";
  var CDN = "https://static-cdn.strpst.com";
  var PAGE_SIZE = 40;

  function text(v) {
    if (v === null || v === undefined) return "";
    return String(v);
  }
  function first(obj, keys, fallback) {
    for (var i = 0; i < keys.length; i++) {
      var v = obj && obj[keys[i]];
      if (v !== undefined && v !== null && v !== "") return v;
    }
    return fallback === undefined ? "" : fallback;
  }
  function queryEncode(v) { return encodeURIComponent(text(v)); }

  function absUrl(u) {
    u = text(u);
    if (!u) return "";
    if (u.indexOf("http://") === 0 || u.indexOf("https://") === 0) return u;
    if (u.charAt(0) === "/") return CDN + u;
    return CDN + "/" + u;
  }

  async function requestJSON(url) {
    var response = await Host.http.request({
      url: url,
      method: "GET",
      timeoutMs: 15000,
      successCacheTTLms: 10000,
      failureCacheTTLms: 2000,
      headers: {
        "Accept": "application/json, text/plain, */*",
        "Referer": REFERER,
        "Origin": "https://stripchat.com",
        "X-Requested-With": "XMLHttpRequest",
        "User-Agent": "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1"
      }
    });
    var status = Number(response && response.status || 0);
    var body = response && response.bodyText;
    if (status < 200 || status >= 300) {
      throw new Error("Stripchat API 请求失败（HTTP " + status + "）");
    }
    if (typeof body !== "string" || !body.length) {
      throw new Error("Stripchat API 返回空数据");
    }
    try { return JSON.parse(body); }
    catch (e) { throw new Error("Stripchat API 返回格式无法识别"); }
  }

  function unwrapModels(data) {
    if (!data) return [];
    if (Array.isArray(data)) return data;

    // 扁平列表：/api/front/models
    if (Array.isArray(data.models)) return data.models;
    if (Array.isArray(data.rooms)) return data.rooms;
    if (Array.isArray(data.items)) return data.items;
    if (data.data) {
      if (Array.isArray(data.data.models)) return data.data.models;
      if (Array.isArray(data.data.rooms)) return data.data.rooms;
      if (Array.isArray(data.data.items)) return data.data.items;
    }

    // v2 blocks 结构：{ blocks: [ { models: [...] }, ... ] }
    if (Array.isArray(data.blocks)) {
      var out = [];
      for (var i = 0; i < data.blocks.length; i++) {
        var block = data.blocks[i] || {};
        var list = block.models || block.rooms || block.items;
        if (Array.isArray(list)) {
          for (var j = 0; j < list.length; j++) out.push(list[j]);
        }
      }
      return out;
    }
    return [];
  }

  function normalizeModel(model) {
    model = model || {};
    var user = model.user || model.userInfo || model;
    var username = text(first(user, ["username", "userName", "name"], first(model, ["username", "userName"], "")));
    var id = text(first(user, ["id", "userId", "modelId"], first(model, ["id", "userId", "modelId"], "")));
    var title = text(first(model, ["topic", "roomTitle", "title", "description"], first(user, ["topic"], username)));
    var cover = absUrl(first(model, [
      "previewUrlThumbSmall", "previewUrl", "preview", "snapshotUrl", "snapshot",
      "popularSnapshotUrl", "roomCover", "image"
    ], ""));
    var avatar = absUrl(first(user, ["avatarUrl", "avatar", "userHeadImg", "profileImage"], first(model, ["avatarUrl", "avatar"], "")));
    if (!cover) cover = avatar;
    var online = first(model, ["isOnline", "isLive", "online"], first(user, ["isOnline", "isLive"], false));
    var viewers = first(model, ["viewersCount", "viewers", "numUsers", "liveWatchedCount"], null);
    var status = text(first(model, ["status"], first(user, ["status"], "")));
    var liveState = "0";
    if (online === true || online === 1 || online === "true" || status === "public") liveState = "1";
    if (status && status !== "public" && status !== "groupShow") liveState = "0";

    return {
      userName: username,
      roomTitle: title || username,
      roomCover: cover,
      userHeadImg: avatar || cover,
      liveState: liveState,
      userId: id,
      roomId: id || username,
      liveWatchedCount: viewers === null || viewers === undefined ? "" : text(viewers)
    };
  }

  function dedupeRooms(models) {
    var seen = Object.create(null);
    var out = [];
    for (var i = 0; i < models.length; i++) {
      var room = normalizeModel(models[i]);
      var key = room.userId || room.userName;
      if (!room.userName || !key || seen[key]) continue;
      seen[key] = true;
      out.push(room);
    }
    return out;
  }

  async function resolveUserId(idOrName) {
    var s = text(idOrName).trim();
    if (!s) throw new Error("缺少主播标识");
    if (/^\d+$/.test(s)) return s;
    var data = await requestJSON(API + "/users/user-ids/" + queryEncode(s));
    // 常见返回：{ userId: 123 } 或 { ids: { name: 123 } } 或直接数字
    if (typeof data === "number") return text(data);
    if (data && data.userId) return text(data.userId);
    if (data && data.id) return text(data.id);
    if (data && data.ids && data.ids[s]) return text(data.ids[s]);
    if (data && typeof data === "object") {
      var keys = Object.keys(data);
      for (var i = 0; i < keys.length; i++) {
        var v = data[keys[i]];
        if (typeof v === "number" || (typeof v === "string" && /^\d+$/.test(v))) return text(v);
      }
    }
    return s;
  }

  async function getModelDetail(idOrName) {
    var id = await resolveUserId(idOrName);
    var cam = await requestJSON(API + "/v2/models/" + queryEncode(id) + "/cam");
    // cam 可能包一层
    var root = cam && (cam.cam || cam.model || cam.user || cam) || {};
    var user = root.user || root.model || root;
    var model = {
      id: first(user, ["id"], id),
      username: first(user, ["username"], idOrName),
      topic: first(root, ["topic"], first(user, ["topic"], "")),
      snapshot: first(root, ["snapshotUrl", "snapshot", "previewUrlThumbSmall"], ""),
      avatarUrl: first(user, ["avatarUrl", "avatar"], ""),
      isLive: first(user, ["isLive", "isOnline"], first(root, ["isCamActive", "isCamAvailable"], false)),
      viewersCount: first(root, ["viewersCount", "viewers"], null),
      status: first(user, ["status"], first(root, ["status"], ""))
    };
    var room = normalizeModel(model);
    room.userId = text(model.id);
    room.roomId = text(model.id);
    return room;
  }

  async function getCategories() {
    return [{
      id: "girls",
      title: "女生",
      icon: "",
      biz: "",
      subList: [
        { id: "girls", parentId: "girls", title: "全部", icon: "", biz: "" },
        { id: "couples", parentId: "girls", title: "情侣", icon: "", biz: "" },
        { id: "men", parentId: "girls", title: "男主播", icon: "", biz: "" },
        { id: "trans", parentId: "girls", title: "跨性别", icon: "", biz: "" }
      ]
    }];
  }

  async function getRooms(payload) {
    payload = payload || {};
    var page = Math.max(1, Number(payload.page || 1));
    var offset = (page - 1) * PAGE_SIZE;
    var category = text(payload.id || payload.categoryId || "girls") || "girls";

    // 优先扁平列表接口（字段更完整，封面是绝对地址）
    var url = API + "/models?limit=" + PAGE_SIZE + "&offset=" + offset +
      "&primaryTag=" + queryEncode(category);
    try {
      var data = await requestJSON(url);
      var rooms = dedupeRooms(unwrapModels(data));
      if (rooms.length) return rooms;
    } catch (e) {
      // 回退 v2 blocks
    }

    var url2 = API + "/v2/models?limit=" + PAGE_SIZE + "&offset=" + offset +
      "&primaryTag=" + queryEncode(category) + "&device=desktop";
    var data2 = await requestJSON(url2);
    return dedupeRooms(unwrapModels(data2));
  }

  async function search(payload) {
    payload = payload || {};
    var keyword = text(payload.keyword || payload.query || payload.searchText || "").trim();
    if (!keyword) return [];

    // 建议接口偶发 403，先试 suggestion，再退到列表过滤
    try {
      var url = API + "/v4/models/search/suggestion?query=" + queryEncode(keyword) +
        "&limit=40&primaryTag=girls";
      var data = await requestJSON(url);
      var rooms = dedupeRooms(unwrapModels(data));
      if (rooms.length) return rooms;
    } catch (e) {}

    // 回退：按用户名解析详情
    try {
      var detail = await getModelDetail(keyword);
      if (detail && detail.userName) return [detail];
    } catch (e2) {}
    return [];
  }

  async function getRoomDetail(payload) {
    payload = payload || {};
    var idOrName = payload.roomId || payload.userId || payload.userName || payload.username || "";
    if (!idOrName) throw new Error("缺少主播标识");
    return await getModelDetail(idOrName);
  }

  async function getLiveState(payload) {
    var room = await getRoomDetail(payload || {});
    return { liveState: room.liveState, room: room };
  }

  globalThis.LiveParsePlugin = {
    apiVersion: 1,
    getCategories: getCategories,
    getRooms: getRooms,
    search: search,
    getRoomDetail: getRoomDetail,
    getLiveState: getLiveState
  };
})();
