(function () {
  "use strict";

  var API = "https://stripchat.com/api/front";
  var REFERER = "https://stripchat.com/";
  var CDN = "https://static-cdn.strpst.com";
  var PAGE_SIZE = 40;
  var UA = "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1";
  var HLS_HOSTS = ["doppiocdn.com", "doppiocdn.net", "doppiocdn.org"];
  // 0.3.2: 播放改走作者的解析代理（liveparse.carsonn.works），由代理解密
  // Mouflon 分片地址并返回带签名的干净清单；直连 HLS 仅作回退。
  var PROXY_BASE = "https://liveparse.carsonn.works/stripchatparse";
  // 同一房间的并发播放请求共享一次取流结果，避免反复请求代理/CDN。
  var playbackInFlight = Object.create(null);

  function text(v) {
    if (v === null || v === undefined) return "";
    return String(v);
  }
  function first(obj, keys, fallback) {
    for (var i = 0; i < keys.length; i++) {
      var v = obj && obj[keys[i]];
      if (v !== undefined && v !== null && v !== "") return v;
    }
    return fallback === undefined ? "" : fallback;
  }
  function queryEncode(v) { return encodeURIComponent(text(v)); }

  function absUrl(u) {
    u = text(u);
    if (!u) return "";
    if (u.indexOf("http://") === 0 || u.indexOf("https://") === 0) return u;
    if (u.charAt(0) === "/") return CDN + u;
    return CDN + "/" + u;
  }

  async function requestJSON(url) {
    var response = await Host.http.request({
      url: url,
      method: "GET",
      timeoutMs: 15000,
      successCacheTTLms: 10000,
      failureCacheTTLms: 2000,
      headers: {
        "Accept": "application/json, text/plain, */*",
        "Referer": REFERER,
        "Origin": "https://stripchat.com",
        "X-Requested-With": "XMLHttpRequest",
        "User-Agent": UA
      }
    });
    var status = Number(response && response.status || 0);
    var body = response && response.bodyText;
    if (status < 200 || status >= 300) {
      throw new Error("Stripchat API 请求失败（HTTP " + status + "）");
    }
    if (typeof body !== "string" || !body.length) {
      throw new Error("Stripchat API 返回空数据");
    }
    try { return JSON.parse(body); }
    catch (e) { throw new Error("Stripchat API 返回格式无法识别"); }
  }

  async function requestText(url) {
    var response = await Host.http.request({
      url: url,
      method: "GET",
      timeoutMs: 4500,
      successCacheTTLms: 0,
      failureCacheTTLms: 500,
      headers: {
        "Accept": "*/*",
        "Referer": REFERER,
        "Origin": "https://stripchat.com",
        "User-Agent": UA
      }
    });
    var status = Number(response && response.status || 0);
    var body = response && response.bodyText;
    if (status < 200 || status >= 300) return null;
    if (typeof body !== "string" || !body.length) return null;
    return body;
  }

  function unwrapModels(data) {
    if (!data) return [];
    if (Array.isArray(data)) return data;
    if (Array.isArray(data.models)) return data.models;
    if (Array.isArray(data.rooms)) return data.rooms;
    if (Array.isArray(data.items)) return data.items;
    if (data.data) {
      if (Array.isArray(data.data.models)) return data.data.models;
      if (Array.isArray(data.data.rooms)) return data.data.rooms;
      if (Array.isArray(data.data.items)) return data.data.items;
    }
    if (Array.isArray(data.blocks)) {
      var out = [];
      for (var i = 0; i < data.blocks.length; i++) {
        var block = data.blocks[i] || {};
        var list = block.models || block.rooms || block.items;
        if (Array.isArray(list)) {
          for (var j = 0; j < list.length; j++) out.push(list[j]);
        }
      }
      return out;
    }
    return [];
  }

  function normalizeModel(model) {
    model = model || {};
    var user = model.user || model.userInfo || model;
    var username = text(first(user, ["username", "userName", "name"], first(model, ["username", "userName"], "")));
    var id = text(first(user, ["id", "userId", "modelId"], first(model, ["id", "userId", "modelId"], "")));
    var title = text(first(model, ["topic", "roomTitle", "title", "description"], first(user, ["topic"], username)));
    var cover = absUrl(first(model, [
      "previewUrlThumbSmall", "previewUrl", "preview", "snapshotUrl", "snapshot",
      "popularSnapshotUrl", "roomCover", "image"
    ], ""));
    var avatar = absUrl(first(user, ["avatarUrl", "avatar", "userHeadImg", "profileImage"], first(model, ["avatarUrl", "avatar"], "")));
    if (!cover) cover = avatar;
    var online = first(model, ["isOnline", "isLive", "online"], first(user, ["isOnline", "isLive"], false));
    var viewers = first(model, ["viewersCount", "viewers", "numUsers", "liveWatchedCount"], null);
    var status = text(first(model, ["status"], first(user, ["status"], "")));
    var liveState = "0";
    if (online === true || online === 1 || online === "true" || status === "public" || status === "groupShow") liveState = "1";
    if (status && status !== "public" && status !== "groupShow") liveState = "0";

    return {
      userName: username,
      roomTitle: title || username,
      roomCover: cover,
      userHeadImg: avatar || cover,
      liveState: liveState,
      userId: id,
      roomId: id || username,
      liveWatchedCount: viewers === null || viewers === undefined ? "" : text(viewers)
    };
  }

  function dedupeRooms(models) {
    var seen = Object.create(null);
    var out = [];
    for (var i = 0; i < models.length; i++) {
      var room = normalizeModel(models[i]);
      var key = room.userId || room.userName;
      if (!room.userName || !key || seen[key]) continue;
      seen[key] = true;
      out.push(room);
    }
    return out;
  }

  async function resolveUserId(idOrName) {
    var s = text(idOrName).trim();
    if (!s) throw new Error("缺少主播标识");
    if (/^\d+$/.test(s)) return s;
    var data = await requestJSON(API + "/users/user-ids/" + queryEncode(s));
    if (typeof data === "number") return text(data);
    if (data && data.userId) return text(data.userId);
    if (data && data.id) return text(data.id);
    if (data && data.ids && data.ids[s]) return text(data.ids[s]);
    if (data && typeof data === "object") {
      var keys = Object.keys(data);
      for (var i = 0; i < keys.length; i++) {
        var v = data[keys[i]];
        if (typeof v === "number" || (typeof v === "string" && /^\d+$/.test(v))) return text(v);
      }
    }
    return s;
  }

  async function fetchCam(idOrName) {
    var id = await resolveUserId(idOrName);
    var data = await requestJSON(API + "/v2/models/" + queryEncode(id) + "/cam");
    return { id: id, data: data };
  }

  function extractUser(camData) {
    var root = camData || {};
    var userWrap = root.user || {};
    var user = userWrap.user || userWrap;
    return user || {};
  }

  async function getModelDetail(idOrName) {
    var fetched = await fetchCam(idOrName);
    var cam = (fetched.data && fetched.data.cam) || {};
    var user = extractUser(fetched.data);
    var model = {
      id: first(user, ["id"], fetched.id),
      username: first(user, ["username"], idOrName),
      topic: first(cam, ["topic"], first(user, ["topic"], "")),
      snapshot: first(cam, ["snapshotUrl", "snapshot", "previewUrlThumbSmall"], ""),
      avatarUrl: first(user, ["avatarUrl", "avatar"], ""),
      isLive: first(user, ["isLive", "isOnline"], first(cam, ["isCamActive", "isCamAvailable"], false)),
      viewersCount: first(cam, ["viewersCount", "viewers"], null),
      status: first(user, ["status"], first(cam, ["status"], ""))
    };
    var room = normalizeModel(model);
    room.userId = text(model.id);
    room.roomId = text(model.id);
    return room;
  }

  function resolvePlaylistUrl(baseUrl, childUrl) {
    var child = text(childUrl).trim();
    if (!child) return "";
    if (/^https?:\/\//i.test(child)) return child;
    if (child.indexOf("//") === 0) return "https:" + child;
    var base = text(baseUrl);
    var originMatch = base.match(/^(https?:\/\/[^/]+)/i);
    if (child.charAt(0) === "/") return originMatch ? originMatch[1] + child : child;
    var slash = base.lastIndexOf("/");
    return (slash >= 0 ? base.slice(0, slash + 1) : base + "/") + child;
  }

  function isMasterPlaylist(body) {
    if (typeof body !== "string") return false;
    return body.replace(/^\uFEFF/, "").trim().indexOf("#EXTM3U") === 0;
  }

  function parseMasterQualities(masterText, masterUrl) {
    var qualities = [];
    if (!masterText) return qualities;
    var lines = masterText.replace(/^\uFEFF/, "").split(/\r?\n/);
    for (var i = 0; i < lines.length; i++) {
      var line = text(lines[i]).trim();
      if (line.toUpperCase().indexOf("#EXT-X-STREAM-INF:") !== 0) continue;
      var nameMatch = line.match(/NAME="([^"]+)"/i);
      var resMatch = line.match(/RESOLUTION=(\d+)x(\d+)/i);
      var bwMatch = line.match(/BANDWIDTH=(\d+)/i);
      var next = "";
      for (var j = i + 1; j < lines.length; j++) {
        var candidate = text(lines[j]).trim();
        if (candidate && candidate.charAt(0) !== "#") { next = candidate; break; }
      }
      if (!next) continue;
      var title = nameMatch ? nameMatch[1] : (resMatch ? (resMatch[2] + "p") : "auto");
      var qn = 0;
      if (resMatch) qn = Number(resMatch[2]) || 0;
      else if (/1080/.test(title)) qn = 1080;
      else if (/720/.test(title)) qn = 720;
      else if (/480/.test(title)) qn = 480;
      else if (/240/.test(title)) qn = 240;
      qualities.push({
        title: title,
        qn: qn,
        bandwidth: bwMatch ? Number(bwMatch[1]) : 0,
        url: resolvePlaylistUrl(masterUrl, next)
      });
    }
    // 有些 master 会重复声明同一子清单；按 URL 去重，避免播放器出现重复档位。
    var unique = [];
    var seen = Object.create(null);
    for (var k = 0; k < qualities.length; k++) {
      if (!qualities[k].url || seen[qualities[k].url]) continue;
      seen[qualities[k].url] = true;
      unique.push(qualities[k]);
    }
    unique.sort(function (a, b) {
      return (b.qn || 0) - (a.qn || 0) || (b.bandwidth || 0) - (a.bandwidth || 0);
    });
    return unique;
  }

  function buildMasterUrls(streamName) {
    var auto = [];
    var standard = [];
    for (var i = 0; i < HLS_HOSTS.length; i++) {
      var host = HLS_HOSTS[i];
      var base = "https://edge-hls." + host + "/hls/" + streamName + "/master/";
      auto.push(base + streamName + "_auto.m3u8");
      standard.push(base + streamName + ".m3u8");
    }
    return { auto: auto, standard: standard };
  }

  async function findFirstValidMaster(urls) {
    // 并发探测并采用“首个有效结果”策略：不再等最慢的 CDN 请求结束。
    var pending = urls.map(function (url, index) {
      return {
        index: index,
        promise: requestText(url).then(function (body) {
          return { index: index, value: isMasterPlaylist(body) ? { url: url, body: body } : null };
        }).catch(function () { return { index: index, value: null }; })
      };
    });
    while (pending.length) {
      var settled = await Promise.race(pending.map(function (item) { return item.promise; }));
      if (settled.value) return settled.value;
      pending = pending.filter(function (item) { return item.index !== settled.index; });
    }
    return null;
  }

  async function getCategories() {
    return [{
      id: "girls",
      title: "女生",
      icon: "",
      biz: "",
      subList: [
        { id: "girls", parentId: "girls", title: "全部", icon: "", biz: "" },
        { id: "couples", parentId: "girls", title: "情侣", icon: "", biz: "" },
        { id: "men", parentId: "girls", title: "男主播", icon: "", biz: "" },
        { id: "trans", parentId: "girls", title: "跨性别", icon: "", biz: "" }
      ]
    }];
  }

  async function getRooms(payload) {
    payload = payload || {};
    var page = Math.max(1, Number(payload.page || 1));
    var offset = (page - 1) * PAGE_SIZE;
    var category = text(payload.id || payload.categoryId || "girls") || "girls";

    var url = API + "/models?limit=" + PAGE_SIZE + "&offset=" + offset +
      "&primaryTag=" + queryEncode(category);
    try {
      var data = await requestJSON(url);
      var rooms = dedupeRooms(unwrapModels(data));
      if (rooms.length) return rooms;
    } catch (e) {}

    var url2 = API + "/v2/models?limit=" + PAGE_SIZE + "&offset=" + offset +
      "&primaryTag=" + queryEncode(category) + "&device=desktop";
    var data2 = await requestJSON(url2);
    return dedupeRooms(unwrapModels(data2));
  }

  async function search(payload) {
    payload = payload || {};
    var keyword = text(payload.keyword || payload.query || payload.searchText || "").trim();
    if (!keyword) return [];
    try {
      var url = API + "/v4/models/search/suggestion?query=" + queryEncode(keyword) +
        "&limit=40&primaryTag=girls";
      var data = await requestJSON(url);
      var rooms = dedupeRooms(unwrapModels(data));
      if (rooms.length) return rooms;
    } catch (e) {}
    try {
      var detail = await getModelDetail(keyword);
      if (detail && detail.userName) return [detail];
    } catch (e2) {}
    return [];
  }

  async function getRoomDetail(payload) {
    payload = payload || {};
    var idOrName = payload.roomId || payload.userId || payload.userName || payload.username || "";
    if (!idOrName) throw new Error("缺少主播标识");
    return await getModelDetail(idOrName);
  }

  async function getLiveState(payload) {
    var room = await getRoomDetail(payload || {});
    return { liveState: room.liveState, room: room };
  }

  function proxyMasterUrl(username) {
    return PROXY_BASE + "/master?room=" + encodeURIComponent(text(username));
  }

  function proxyQualitiesUrl(username) {
    return PROXY_BASE + "/qualities?room=" + encodeURIComponent(text(username));
  }

  // 只接受代理返回的带签名清单地址（/playlist? + exp + sig）
  function isSignedProxyPlaylistUrl(url) {
    var value = text(url).trim();
    if (value.indexOf(PROXY_BASE + "/playlist?") !== 0 || !/[?&]sig=[^&]+/.test(value)) return false;
    var match = value.match(/[?&]exp=(\d+)/);
    if (!match) return false;
    var expires = Number(match[1]);
    // 兼容秒/毫秒时间戳；给播放器留出少量启动余量。
    var now = Date.now();
    if (expires < 1000000000000) expires *= 1000;
    return isFinite(expires) && expires > now + 5000;
  }

  async function requestProxyJSON(url, username) {
    var response = await Host.http.request({
      url: url,
      method: "GET",
      // 签名清单有有效期，不能长时间复用 Host 缓存中的旧响应。
      timeoutMs: 4000,
      successCacheTTLms: 0,
      failureCacheTTLms: 500,
      headers: {
        "Accept": "application/json, text/plain, */*",
        "Referer": "https://stripchat.com/" + encodeURIComponent(text(username)),
        "Origin": "https://stripchat.com",
        "User-Agent": UA
      }
    });
    var status = Number(response && response.status || 0);
    var body = response && response.bodyText;
    if (status < 200 || status >= 300) return null;
    if (typeof body !== "string" || !body.length) return null;
    try { return JSON.parse(body); }
    catch (e) { return null; }
  }

  // 从代理拉取可用清晰度；只保留带签名的清单地址，失败返回空数组
  async function fetchProxyQualities(username) {
    var data = null;
    try {
      data = await requestProxyJSON(proxyQualitiesUrl(username), username);
    } catch (e) {
      return [];
    }
    if (!data) return [];
    var list = Array.isArray(data.qualitys) ? data.qualitys : [];
    var out = [];
    var seen = Object.create(null);
    for (var i = 0; i < list.length; i++) {
      var item = list[i] || {};
      var url = text(item.url).trim();
      if (!isSignedProxyPlaylistUrl(url) || seen[url]) continue;
      seen[url] = true;
      out.push({
        title: text(item.title).trim() || "清晰度",
        qn: Number(item.qn) || 0,
        url: url
      });
    }
    // 代理返回顺序不固定；同一分辨率优先保留首个有效签名地址。
    out.sort(function (a, b) { return b.qn - a.qn; });
    var unique = [];
    var seenQn = Object.create(null);
    for (var j = 0; j < out.length; j++) {
      var key = out[j].qn ? "qn:" + out[j].qn : "url:" + out[j].url;
      if (seenQn[key]) continue;
      seenQn[key] = true;
      unique.push(out[j]);
    }
    return unique;
  }

  // 0.3.1 已验证的 LiveQualityModel 形态，保持不变
  function makeQuality(roomId, title, qn, url, headers, source, tier) {
    return {
      roomId: text(roomId),
      title: title,
      qn: qn,
      url: url,
      liveCodeType: "m3u8",
      liveType: "stripchat",
      userAgent: UA,
      headers: headers,
      // refreshPlayback 用稳定标识找回用户原先选择的线路/清晰度。
      requestContext: {
        roomId: text(roomId),
        source: text(source),
        tier: text(tier)
      },
      playbackHints: {
        streamFormat: "hlsLive",
        latencyMode: "standard",
        isLive: true
      }
    };
  }

  async function getPlaybackInternal(payload) {
    payload = payload || {};
    var idOrName = payload.roomId || payload.userId || payload.userName || payload.username || "";
    if (!idOrName) Host.raise("UPSTREAM", "缺少主播标识");

    var fetched = await fetchCam(idOrName);
    var cam = (fetched.data && fetched.data.cam) || {};
    var user = extractUser(fetched.data);
    var status = text(first(user, ["status"], ""));
    var isLive = first(user, ["isLive"], first(cam, ["isCamActive", "isCamAvailable"], false));
    var streamName = text(first(cam, ["streamName"], fetched.id));

    if (!streamName) Host.raise("UPSTREAM", "无法获取流名称");
    if (status && status !== "public" && status !== "groupShow") {
      Host.raise("UPSTREAM", "主播当前不在公开直播（状态: " + status + "）");
    }
    if (isLive === false || isLive === 0 || isLive === "false" || isLive === "0") {
      Host.raise("UPSTREAM", "主播未开播");
    }

    var headers = {
      referer: REFERER,
      origin: "https://stripchat.com",
      "user-agent": UA
    };

    // 0.3.2: 优先走代理播放 —— 代理已解密 Mouflon，返回带签名的干净清单
    var username = text(first(user, ["username"], "")) || idOrName;
    var proxyQualities = await fetchProxyQualities(username);
    if (proxyQualities.length) {
      var qualities = [];
      // 0.3.3: 自动档直接走最高清晰度的代理清单地址，不再经过 master
      // （master 多一跳，直播分片 2 秒一滑，播放器拿到第一片时已过期，卡在「正在连接」）
      var bestProxy = proxyQualities[0];
      for (var b = 1; b < proxyQualities.length; b++) {
        if (proxyQualities[b].qn > bestProxy.qn) bestProxy = proxyQualities[b];
      }
      qualities.push(makeQuality(fetched.id, "自动", 10000, bestProxy.url, headers, "proxy", "auto"));
      for (var p = 0; p < proxyQualities.length; p++) {
        var pq = proxyQualities[p];
        qualities.push(makeQuality(
          fetched.id,
          pq.title || (pq.qn ? pq.qn + "p" : "清晰度"),
          pq.qn || (9000 - p),
          pq.url,
          headers,
          "proxy",
          "qn:" + text(pq.qn || (9000 - p))
        ));
      }
      return [{
        cdn: "proxy",
        displayName: "Stripchat",
        qualitys: qualities
      }];
    }

    // 代理无可用清晰度时，回退 0.3.1 直连 HLS 逻辑
    var masterGroups = buildMasterUrls(streamName);
    var foundMaster = await findFirstValidMaster(masterGroups.auto);
    if (!foundMaster) foundMaster = await findFirstValidMaster(masterGroups.standard);
    var masterUrl = foundMaster ? foundMaster.url : masterGroups.auto[0];
    var masterText = foundMaster ? foundMaster.body : "";

    var parsed = parseMasterQualities(masterText || "", masterUrl);
    var directQualities = [];

    // 自动档（master）
    directQualities.push(makeQuality(fetched.id, "自动", 10000, masterUrl, headers, "direct", "auto"));

    for (var q = 0; q < parsed.length; q++) {
      var item = parsed[q];
      // 过滤明显无效/重复
      if (!item.url) continue;
      directQualities.push(makeQuality(
        fetched.id,
        item.title || (item.qn ? item.qn + "p" : "清晰度"),
        item.qn || (9000 - q),
        item.url,
        headers,
        "direct",
        "qn:" + text(item.qn || (9000 - q))
      ));
    }

    return [{
      cdn: "doppiocdn",
      displayName: "Stripchat",
      requestContext: { roomId: text(fetched.id) },
      qualitys: directQualities
    }];
  }

  async function getPlayback(payload) {
    payload = payload || {};
    var roomKey = text(payload.roomId || payload.userId || payload.userName || payload.username || "").trim().toLowerCase();
    if (!roomKey) return await getPlaybackInternal(payload);
    if (playbackInFlight[roomKey]) return await playbackInFlight[roomKey];
    var task = getPlaybackInternal(payload);
    playbackInFlight[roomKey] = task;
    try {
      return await task;
    } finally {
      if (playbackInFlight[roomKey] === task) delete playbackInFlight[roomKey];
    }
  }

  // AngelLive 宿主在播放地址失效/需要重连时可调用此钩子。
  // 重新请求主播 cam 与代理签名地址，并优先返回原先选中的线路和清晰度。
  async function refreshPlayback(payload) {
    payload = payload || {};
    var quality = payload.quality || {};
    var context = quality.requestContext || {};
    var roomId = text(payload.roomId || quality.roomId || context.roomId || "").trim();
    if (!roomId) Host.raise("UPSTREAM", "刷新播放地址时缺少主播标识");

    var groups = await getPlayback({ roomId: roomId });
    var available = [];
    for (var i = 0; i < groups.length; i++) {
      var list = groups[i] && groups[i].qualitys || [];
      for (var j = 0; j < list.length; j++) available.push(list[j]);
    }
    if (!available.length) Host.raise("UPSTREAM", "刷新后没有可用播放地址");

    var wantedSource = text(context.source);
    var wantedTier = text(context.tier);
    var wantedQn = Number(quality.qn) || 0;
    for (var k = 0; k < available.length; k++) {
      var nextContext = available[k].requestContext || {};
      if (wantedTier && text(nextContext.tier) === wantedTier &&
          (!wantedSource || text(nextContext.source) === wantedSource)) return available[k];
    }
    if (wantedQn) {
      for (var n = 0; n < available.length; n++) {
        if (Number(available[n].qn) === wantedQn) return available[n];
      }
    }
    return available[0];
  }

  globalThis.LiveParsePlugin = {
    apiVersion: 1,
    getCategories: getCategories,
    getRooms: getRooms,
    search: search,
    getRoomDetail: getRoomDetail,
    getLiveState: getLiveState,
    getPlayback: getPlayback,
    refreshPlayback: refreshPlayback
  };
})();
