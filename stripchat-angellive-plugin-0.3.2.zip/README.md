# Stripchat Angel Live Plugin 0.3.2

- 列表 / 搜索 / 详情 / 状态 / 播放
- liveCodeType 使用宿主要求的 `m3u8`
- 播放：优先走作者的解析代理 `liveparse.carsonn.works/stripchatparse`（代理解密 Mouflon，返回带签名 `exp`/`sig` 的干净 HLS 清单）；代理无可用清晰度时回退直连 HLS（edge-hls.doppiocdn.*）
