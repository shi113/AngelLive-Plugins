
const fs = require("fs");
const vm = require("vm");
const source = fs.readFileSync(process.argv[2], "utf8");
const calls = [];
const fixtures = {
  "/api/front/v2/models?limit=40&offset=0&primaryTag=girls&device=desktop": {
    models: [
      { id: 203402412, username: "Linh_2004", topic: "hello", snapshot: "https://img.example/cover.jpg", avatarUrl: "https://img.example/avatar.jpg", isOnline: true, viewersCount: 123 },
      { id: 203402413, username: "offline_model", topic: "away", isOnline: false }
    ]
  },
  "/api/front/v4/models/search/suggestion?query=Linh&limit=40&primaryTag=girls": {
    models: [{ id: 203402412, username: "Linh_2004", topic: "hello", isOnline: true }]
  },
  "/api/front/users/user-ids/Linh_2004": { id: 203402412 },
  "/api/front/v2/models/203402412/cam": {
    cam: { streamName: "203402412", isCamActive: true },
    user: { user: { id: 203402412, username: "Linh_2004", status: "public", isLive: true, topic: "test" } }
  }
};
const Host = {
  http: {
    request: async ({url}) => {
      calls.push(url);
      const path = new URL(url).pathname + new URL(url).search;
      if (!(path in fixtures)) return {status: 404, bodyText: JSON.stringify({error:"not found"})};
      return {status: 200, bodyText: JSON.stringify(fixtures[path])};
    }
  }
};
const sandbox = { Host, console, encodeURIComponent, URL, Promise };
vm.runInNewContext(source, sandbox);
(async () => {
  const p = sandbox.LiveParsePlugin;
  if (p.apiVersion !== 1) throw new Error("apiVersion mismatch");
  const cats = await p.getCategories();
  if (!Array.isArray(cats) || cats[0].id !== "girls") throw new Error("categories failed");
  const rooms = await p.getRooms({page:1,id:"girls"});
  if (rooms.length !== 2 || rooms[0].userName !== "Linh_2004" || rooms[0].userId !== "203402412") throw new Error("rooms mapping failed");
  const results = await p.search({keyword:"Linh"});
  if (results.length !== 1 || results[0].roomId !== "203402412") throw new Error("search mapping failed");
  const detail = await p.getRoomDetail({userName:"Linh_2004"});
  if (detail.userId !== "203402412" || detail.liveState !== "1") throw new Error("detail mapping failed");
  const state = await p.getLiveState({roomId:"203402412"});
  if (state.liveState !== "1") throw new Error("live state failed");
  console.log("PASS categories, rooms, search, username->ID, detail, numeric-ID detail, live state; HTTP calls="+calls.length);
})().catch(e => { console.error(e.stack || e); process.exit(1); });
