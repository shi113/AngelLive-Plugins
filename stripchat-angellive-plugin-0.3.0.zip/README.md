# Stripchat Angel Live Plugin 0.3.0

功能：分类 / 房间列表 / 搜索 / 详情 / 直播状态 / **播放(HLS)**

## 播放说明
- 使用 `edge-hls.doppiocdn.*` 的 master m3u8
- 部分线路可能带 Mouflon 标签；若宿主播放器无法解码，会出现有地址但无法出画
- 仅支持公开直播（public / groupShow）

## 数据接口
- 列表：`/api/front/models` 或 `/api/front/v2/models`
- 详情：`/api/front/v2/models/{id}/cam`
- 播放：HLS `https://edge-hls.doppiocdn.com/hls/{streamName}/master/{streamName}_auto.m3u8`
