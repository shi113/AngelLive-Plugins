# Stripchat Angel Live Plugin 0.2.0

当前版本仅实现公开主播浏览、搜索、详情与直播状态。播放能力暂不开放。

## 数据来源
- 主播列表：`/api/front/v2/models`
- 搜索建议：`/api/front/v4/models/search/suggestion`
- 用户 ID：`/api/front/users/user-ids/{username}`
- 主播详情：`/api/front/v2/models/{id}/cam`

仅调用公开接口；不携带账号 Cookie，不尝试绕过站点风控或访问控制。

## 说明
- 收藏由 Angel Live 宿主管理。
- Stripchat 接口可能按地区、网络环境或站点风控返回 403/429；浏览器可访问不代表宿主网络请求必然成功。
- 播放暂未实现。
