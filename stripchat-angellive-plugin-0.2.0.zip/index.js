(function () {
  "use strict";

  var API = "https://stripchat.com/api/front";
  var REFERER = "https://stripchat.com/";
  var PAGE_SIZE = 40;

  function text(v) {
    if (v === null || v === undefined) return "";
    return String(v);
  }
  function first(obj, keys, fallback) {
    for (var i = 0; i < keys.length; i++) {
      var v = obj && obj[keys[i]];
      if (v !== undefined && v !== null && v !== "") return v;
    }
    return fallback === undefined ? "" : fallback;
  }
  function queryEncode(v) { return encodeURIComponent(text(v)); }

  async function requestJSON(url) {
    var response = await Host.http.request({
      url: url,
      method: "GET",
      timeoutMs: 15000,
      successCacheTTLms: 15000,
      failureCacheTTLms: 2000,
      headers: {
        "Accept": "application/json, text/plain, */*",
        "Referer": REFERER,
        "Origin": "https://stripchat.com",
        "X-Requested-With": "XMLHttpRequest"
      }
    });
    var status = Number(response && response.status || 0);
    var body = response && response.bodyText;
    if (status < 200 || status >= 300) {
      throw new Error("Stripchat API 请求失败（HTTP " + status + "）");
    }
    if (typeof body !== "string" || !body.length) {
      throw new Error("Stripchat API 返回空数据");
    }
    try { return JSON.parse(body); }
    catch (e) { throw new Error("Stripchat API 返回格式无法识别"); }
  }

  function unwrapModels(data) {
    if (Array.isArray(data)) return data;
    var candidates = [
      data && data.models, data && data.rooms, data && data.items,
      data && data.data && data.data.models,
      data && data.data && data.data.rooms,
      data && data.data && data.data.items
    ];
    for (var i = 0; i < candidates.length; i++) {
      if (Array.isArray(candidates[i])) return candidates[i];
    }
    return [];
  }

  function normalizeModel(model) {
    model = model || {};
    var user = model.user || model.userInfo || model;
    var username = text(first(user, ["username", "userName", "name"], first(model, ["username", "userName"], "")));
    var id = text(first(user, ["id", "userId", "modelId"], first(model, ["id", "userId", "modelId"], "")));
    var title = text(first(model, ["topic", "roomTitle", "title", "description"], first(user, ["topic"], username)));
    var cover = text(first(model, ["snapshot", "snapshotUrl", "previewUrl", "preview", "roomCover", "image"], ""));
    var avatar = text(first(user, ["avatarUrl", "avatar", "userHeadImg", "profileImage"], first(model, ["avatarUrl", "avatar"], "")));
    var online = first(model, ["isOnline", "isLive", "online"], first(user, ["isOnline", "isLive"], false));
    var viewers = first(model, ["viewersCount", "viewers", "numUsers", "liveWatchedCount"], null);
    return {
      userName: username,
      roomTitle: title || username,
      roomCover: cover,
      userHeadImg: avatar,
      liveState: online === true || online === 1 || online === "true" ? "1" : "0",
      userId: id,
      roomId: id || username,
      liveWatchedCount: viewers === null ? null : text(viewers)
    };
  }

  function dedupeRooms(models) {
    var seen = Object.create(null);
    var out = [];
    for (var i = 0; i < models.length; i++) {
      var room = normalizeModel(models[i]);
      var key = room.userId || room.userName;
      if (!room.userName || !key || seen[key]) continue;
      seen[key] = true;
      out.push(room);
    }
    return out;
  }

  async function resolveId(usernameOrId) {
    var value = text(usernameOrId).trim().replace(/^https?:\/\/(?:[a-z]{2}\.)?stripchat\.com\//i, "").replace(/\/.*$/, "");
    if (!value) throw new Error("缺少主播名或主播 ID");
    if (/^\d+$/.test(value)) return value;
    var data = await requestJSON(API + "/users/user-ids/" + queryEncode(value));
    var id = first(data, ["id", "userId"], "");
    if (!id) throw new Error("找不到主播：" + value);
    return text(id);
  }

  async function getModelDetail(usernameOrId) {
    var id = await resolveId(usernameOrId);
    var data = await requestJSON(API + "/v2/models/" + queryEncode(id) + "/cam");
    var cam = data && data.cam || {};
    var userWrap = data && data.user || {};
    var user = userWrap.user || userWrap;
    var model = {
      id: first(user, ["id"], id),
      userId: first(user, ["id"], id),
      username: first(user, ["username", "userName"], text(usernameOrId)),
      topic: first(user, ["topic"], first(cam, ["topic"], "")),
      snapshot: first(cam, ["snapshot", "snapshotUrl"], first(user, ["snapshot", "snapshotUrl"], "")),
      avatarUrl: first(user, ["avatarUrl", "avatar"], ""),
      isOnline: first(user, ["isLive", "isOnline"], first(cam, ["isCamActive", "isCamAvailable"], false)),
      viewersCount: first(cam, ["viewersCount", "viewers"], null),
      status: first(user, ["status"], "")
    };
    var room = normalizeModel(model);
    room.userId = id;
    room.roomId = id;
    if (model.status && model.status !== "public") room.liveState = "0";
    return room;
  }

  async function getCategories() {
    return [{ id: "girls", name: "女生", title: "女生" }];
  }

  async function getRooms(payload) {
    payload = payload || {};
    var page = Math.max(1, Number(payload.page || 1));
    var offset = (page - 1) * PAGE_SIZE;
    var category = text(payload.id || payload.categoryId || "girls") || "girls";
    var url = API + "/v2/models?limit=" + PAGE_SIZE + "&offset=" + offset +
      "&primaryTag=" + queryEncode(category) + "&device=desktop";
    var data = await requestJSON(url);
    return dedupeRooms(unwrapModels(data));
  }

  async function search(payload) {
    payload = payload || {};
    var keyword = text(payload.keyword || payload.query || payload.searchText || "").trim();
    if (!keyword) return [];
    var url = API + "/v4/models/search/suggestion?query=" + queryEncode(keyword) +
      "&limit=40&primaryTag=girls";
    var data = await requestJSON(url);
    return dedupeRooms(unwrapModels(data));
  }

  async function getRoomDetail(payload) {
    payload = payload || {};
    var idOrName = payload.roomId || payload.userId || payload.userName || payload.username || "";
    if (!idOrName) throw new Error("缺少主播标识");
    return await getModelDetail(idOrName);
  }

  async function getLiveState(payload) {
    var room = await getRoomDetail(payload || {});
    return { liveState: room.liveState, room: room };
  }

  globalThis.LiveParsePlugin = {
    apiVersion: 1,
    getCategories: getCategories,
    getRooms: getRooms,
    search: search,
    getRoomDetail: getRoomDetail,
    getLiveState: getLiveState
  };
})();
