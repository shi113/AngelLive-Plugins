# Stripchat Angel Live Plugin 0.3.1

- 列表 / 搜索 / 详情 / 状态 / 播放
- liveCodeType 使用宿主要求的 `m3u8`
- HLS: edge-hls.doppiocdn.*
