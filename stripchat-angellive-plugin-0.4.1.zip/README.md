# Stripchat Angel Live Plugin 0.4.0

- 主播列表、搜索、详情、直播状态与 HLS 播放。
- 保留 AngelLive 已验证的 `LiveQualityModel` 字段和 `m3u8` 类型，不更改宿主接口。
- 新增 `refreshPlayback`：播放地址失效时重新请求主播信息与播放清单，并优先保持原先选中的线路/清晰度。
- 播放优先使用解析代理返回的签名清单；签名地址会校验有效期，签名响应不使用长缓存。
- 代理不可用时回退 Doppiocdn 直连 HLS。CDN 并发探测采用首个有效结果，不等待最慢线路。
- 代理清晰度与直连子清单去重、排序；同一主播的并发取流请求合并。
- 直连清单请求超时 4.5 秒，代理清单请求超时 4 秒，以缩短失败线路的等待时间。

**边界说明：** 插件负责获取播放地址和在宿主调用 `refreshPlayback` 时刷新地址；实际缓冲、预读、解码及播放状态展示仍由 AngelLive 宿主播放器控制。


## 0.4.1 图标资源

- 新增 `assets/tv_community.stripchat_big.png` 与深色模式资源，供 iOS 配置卡片读取。
- 同时提供 `live_card`、`pad_live_card`、`mini_live_card` 与 TV 小图资源。
- 插件 ID 保持 `community.stripchat`；本次不改动播放逻辑。
