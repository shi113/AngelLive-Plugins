# Stripchat for Angel Live — development preview

This is an independent JavaScript plugin package for Angel Live (plugin API v1).

## Included in this preview

- Public room category/list
- Username search
- Room detail and live-state lookup
- Local favorites through Angel Live's native room identity (`userId`/`roomId`)
- Public HLS playback URL resolution when the upstream returns a public HLS stream

## Important limitations

- This preview is not yet verified against a live iPhone installation.
- The upstream site may return Cloudflare/access-denied responses. The plugin does not attempt to bypass anti-bot checks, obtain browser challenge cookies, impersonate a browser TLS stack, or use an external challenge-solving service.
- Only rooms whose upstream status is `public` are eligible for playback. Private, group, P2P, paid, and member-only rooms are deliberately rejected.
- The current HLS path is based on public community references and may need adjustment against a current, ordinary public-room response. Stripchat can change API and CDN behavior without notice.
- Some streams may use a segment/playlist transformation not supported by this preview. No DRM/Mouflon decryption or access-control circumvention is included.
- No login, Cookie, API key, or account credential is requested or stored.

## Package structure

- `manifest.json` — Angel Live plugin manifest
- `index.js` — plugin entry point

## Next verification steps

1. Install this package through Angel Live's normal user-managed plugin source/import flow.
2. Test category and room-list responses on an iPhone.
3. Test search and room detail for one public room.
4. Test public HLS playback. If a request is rejected, preserve the HTTP status and a redacted error only; do not share account cookies or tokens.
5. Update the parser to the actual current response shape before calling this a stable release.
