/*
 * Angel Live community plugin — Stripchat
 * Development preview 0.1.0
 *
 * Only public room metadata and publicly available live streams are handled.
 * No private/group/paid room access, anti-bot challenge bypass, DRM circumvention,
 * or credential extraction is implemented.
 */

(function (global) {
  "use strict";

  var BASE = "https://zh.stripchat.com";
  var LIVE_TYPE = "stripchat";
  var PAGE_SIZE = 48;
  var ID_CACHE = Object.create(null);

  function text(value, fallback) {
    if (value === null || value === undefined) return fallback || "";
    return String(value).trim();
  }

  function first(object, keys, fallback) {
    for (var i = 0; i < keys.length; i++) {
      var value = object && object[keys[i]];
      if (value !== null && value !== undefined && value !== "") return value;
    }
    return fallback;
  }

  function encode(value) {
    return encodeURIComponent(text(value));
  }

  function unwrapModels(payload) {
    if (Array.isArray(payload)) return payload;
    var candidates = [
      payload && payload.models,
      payload && payload.items,
      payload && payload.data && payload.data.models,
      payload && payload.data && payload.data.items,
      payload && payload.result && payload.result.models
    ];
    for (var i = 0; i < candidates.length; i++) {
      if (Array.isArray(candidates[i])) return candidates[i];
    }
    return [];
  }

  async function requestJSON(url) {
    var response = await Host.http.request({
      url: url,
      method: "GET",
      timeout: 15000,
      headers: {
        "Accept": "application/json, text/plain, */*",
        "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8",
        "Referer": BASE + "/"
      }
    });

    var status = Number(response && response.status || 0);
    if (status < 200 || status >= 300) {
      throw new Error("上游请求失败（HTTP " + status + "）。如果网站返回访问限制，请稍后重试或使用网站本身；插件不会尝试绕过验证。");
    }

    var body = response && response.bodyText;
    if (typeof body !== "string" || !body.length) {
      throw new Error("上游返回了空响应。");
    }
    try {
      return JSON.parse(body);
    } catch (_) {
      throw new Error("上游响应不是有效 JSON；接口可能已调整或需要网站正常会话。");
    }
  }

  function normalizeRoom(model) {
    if (!model || typeof model !== "object") return null;

    var username = text(first(model, ["username", "userName", "name", "displayName"], ""));
    var id = text(first(model, ["id", "modelId", "userId", "sc_id"], ""));
    if (!username || !id) return null;

    var status = text(first(model, ["status", "broadcastStatus", "userStatus"], "")).toLowerCase();
    var active = first(model, ["isCamActive", "isLive", "isOnline", "live"], null);
    var isLive = active === true || active === 1 || active === "1" || status === "public" || status === "idle";

    return {
      userName: username,
      roomTitle: text(first(model, ["roomSubject", "subject", "topic", "description"], username)),
      roomCover: text(first(model, ["previewUrl", "previewUrlThumb", "previewUrlThumbSmall", "snapshot", "avatarUrl"], "")),
      userHeadImg: text(first(model, ["avatarUrl", "avatarUrlMedium", "avatar", "userHeadImg"], "")),
      liveState: isLive ? "1" : "0",
      userId: id,
      roomId: id,
      liveWatchedCount: text(first(model, ["viewersCount", "viewers", "numUsers", "watchers"], ""))
    };
  }

  function normalizeRooms(payload) {
    return unwrapModels(payload).map(normalizeRoom).filter(Boolean);
  }

  async function resolveUserId(usernameOrId) {
    var value = text(usernameOrId);
    if (!value) throw new Error("缺少主播标识。");
    if (/^\d+$/.test(value)) return value;
    var key = value.toLowerCase();
    if (ID_CACHE[key]) return ID_CACHE[key];

    var payload = await requestJSON(BASE + "/api/front/v2/users/username/" + encode(value));
    var item = payload && (payload.item || payload.user || payload.data && payload.data.item);
    var id = text(first(item, ["id", "userId", "modelId"], ""));
    if (!id) throw new Error("无法从主播主页解析稳定 ID。");
    ID_CACHE[key] = id;
    return id;
  }

  async function getCamById(id) {
    return await requestJSON(
      BASE + "/api/front/v2/models/" + encode(id) + "/cam?primaryTag=girls&withRecentShow=1"
    );
  }

  function camRoom(payload, fallbackId) {
    var user = payload && payload.user && payload.user.user;
    var cam = payload && payload.cam;
    if (!user && !cam) throw new Error("主播详情响应结构不完整。");

    var merged = Object.assign({}, user || {}, cam || {});
    merged.id = first(user, ["id", "userId"], fallbackId);
    merged.username = first(user, ["username", "userName"], first(cam, ["username"], ""));
    merged.status = first(user, ["status"], "off");
    merged.isCamActive = first(cam, ["isCamActive", "isCamAvailable"], first(user, ["isLive"], false));
    merged.roomSubject = first(cam, ["subject", "roomSubject", "topic"], first(user, ["statusMessage"], merged.username));
    merged.previewUrl = first(cam, ["snapshot", "previewUrl"], first(user, ["previewUrl", "avatarUrl"], ""));
    merged.avatarUrl = first(user, ["avatarUrl", "avatar"], "");
    merged.viewersCount = first(cam, ["viewersCount", "viewers"], first(user, ["viewersCount"], ""));
    return normalizeRoom(merged);
  }

  async function listModels(page) {
    var offset = Math.max(0, (Number(page || 1) - 1) * PAGE_SIZE);
    var url = BASE + "/api/front/models?limit=" + PAGE_SIZE +
      "&offset=" + offset + "&primaryTag=girls&sortBy=trending";
    return normalizeRooms(await requestJSON(url));
  }

  async function searchModels(keyword, page) {
    var query = text(keyword);
    if (!query) return [];
    var pageNumber = Math.max(1, Number(page || 1));
    var url = BASE + "/api/front/v4/models/search/group/username?query=" + encode(query) +
      "&primaryTag=girls&limit=" + PAGE_SIZE + "&offset=" + ((pageNumber - 1) * PAGE_SIZE);
    return normalizeRooms(await requestJSON(url));
  }

  async function getPlaybackForInput(input) {
    var id = await resolveUserId(first(input, ["userId", "roomId"], ""));
    var payload = await getCamById(id);
    var user = payload && payload.user && payload.user.user;
    var cam = payload && payload.cam;
    var status = text(first(user, ["status"], "off")).toLowerCase();
    var active = first(cam, ["isCamActive"], first(user, ["isLive"], false));
    var streamName = text(first(cam, ["streamName", "stream"], ""));
    var servers = cam && cam.viewServers || {};
    var server = text(first(servers, ["flashphoner-hls", "hls"], ""));

    if (status !== "public" || !(active === true || active === 1 || active === "1")) {
      throw new Error("该主播当前没有可公开播放的直播流。私人房、群组房和付费房不在支持范围内。");
    }
    if (!streamName || !server) {
      throw new Error("上游没有返回公开 HLS 播放参数。");
    }

    // Public HLS master playlist only. No Mouflon/DRM decryption or access-control bypass.
    var url = "https://b-" + encode(server) + ".doppiocdn.com/hls/" +
      encode(streamName) + "/master_" + encode(streamName) + ".m3u8";
    return [{
      cdn: "DoppioCDN",
      displayName: "公开线路",
      qualitys: [{
        roomId: id,
        title: "Auto",
        qn: 0,
        url: url,
        liveCodeType: "m3u8",
        liveType: LIVE_TYPE,
        headers: { "Referer": BASE + "/" },
        playbackHints: {
          streamFormat: "hlsLive",
          isLive: true,
          preferredEngines: ["mePlayer"],
          selectionBehavior: "direct"
        }
      }]
    }];
  }

  global.LiveParsePlugin = {
    apiVersion: 1,

    async getCategories() {
      return [{
        id: "stripchat-root",
        title: "Stripchat",
        icon: "",
        biz: "",
        subList: [{
          id: "public",
          parentId: "stripchat-root",
          title: "公开直播",
          icon: "",
          biz: "girls"
        }]
      }];
    },

    async getRooms(input) {
      return await listModels(input && input.page || 1);
    },

    async search(input) {
      return await searchModels(input && input.keyword, input && input.page || 1);
    },

    async getRoomDetail(input) {
      var id = await resolveUserId(first(input, ["userId", "roomId"], ""));
      var payload = await getCamById(id);
      var room = camRoom(payload, id);
      if (!room) throw new Error("主播详情无法转换为房间数据。");
      return room;
    },

    async getLiveState(input) {
      var id = await resolveUserId(first(input, ["userId", "roomId"], ""));
      var payload = await getCamById(id);
      var user = payload && payload.user && payload.user.user;
      var cam = payload && payload.cam;
      var status = text(first(user, ["status"], "off")).toLowerCase();
      var active = first(cam, ["isCamActive", "isCamAvailable"], first(user, ["isLive"], false));
      var isLive = (active === true || active === 1 || active === "1") && status === "public";
      return { liveState: isLive ? "1" : "0" };
    },

    async getPlayback(input) {
      return await getPlaybackForInput(input);
    },

    async refreshPlayback(input) {
      var result = await getPlaybackForInput({ roomId: input && input.roomId, userId: input && input.userId });
      if (!result.length || !result[0].qualitys.length) throw new Error("无法刷新公开播放地址。");
      return result[0].qualitys[0];
    }
  };
})(this);
